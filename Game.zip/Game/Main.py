import pygame

# Initialize the Pygame
pygame.init()


# for creating the screen
screen = pygame.display.set_mode((800, 800))

# Title and Icon
pygame.display.set_caption("Maze Gamers")
icon = pygame.image.load('person.png')
pygame.display.set_icon(icon)

# Player
playerImg = pygame.image.load('mammal.png')
playerX = 70
playerY = 100

def player(x, y):
    screen.blit(playerImg, (x, y))



# Game Loop
running = True
while running:
    # background color
     screen.fill((153, 127, 143))

     for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

# keystroke for movement control
        if event.type == pygame.KEYDOWN:
            print("key stroke is pressed")
            if event.key == pygame.K_LEFT:
              print("left arrow is pressed")
            if event.key == pygame.K_RIGHT:
                    print("right key is pressed")
        if event.type == pygame.KEYUP:
            if event.key == pygame.K_LEFT or event.key == pygame.K_RIGHT:
                print("key storkes are pressed")

        player(playerX, playerY)
        pygame.display.update()
